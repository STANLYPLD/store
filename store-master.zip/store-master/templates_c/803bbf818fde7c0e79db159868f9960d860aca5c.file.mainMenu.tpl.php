<?php /* Smarty version Smarty-3.1.18, created on 2016-08-29 23:10:17
         compiled from "./templates/mainMenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:201376654157c495d4642aa8-86683102%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '803bbf818fde7c0e79db159868f9960d860aca5c' => 
    array (
      0 => './templates/mainMenu.tpl',
      1 => 1472501400,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '201376654157c495d4642aa8-86683102',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57c495d4643642_73316205',
  'variables' => 
  array (
    'AAA' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57c495d4643642_73316205')) {function content_57c495d4643642_73316205($_smarty_tpl) {?><div class="mainMenu">
    <a href="#">home</a>
    <a href="#">drama</a>
    <a href="#"><?php echo $_smarty_tpl->tpl_vars['AAA']->value;?>
</a>
</div><?php }} ?>
