<?php /* Smarty version Smarty-3.1.18, created on 2016-09-02 02:34:28
         compiled from ".\templates\home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:449957c77c7aeacaf3-21245086%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97d060df136bc68287855ad0037b446ebb85b73d' => 
    array (
      0 => '.\\templates\\home.tpl',
      1 => 1472776467,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '449957c77c7aeacaf3-21245086',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57c77c7b38c415_02829059',
  'variables' => 
  array (
    'NAME' => 0,
    'TABLES' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57c77c7b38c415_02829059')) {function content_57c77c7b38c415_02829059($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"> 

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Logo</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="jumbotron">
            <h1>Hello, world!</h1>
            <p>This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
            <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a></p>
        </div>
        <div class="container-fluid text-center">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                    <p><a href="#">Link</a></p>
                    <p><a href="#">Link</a></p>
                    <p><a href="#">Link</a></p>
                </div>

                <div class="col-sm-10 col-md-4">
                    <div class="col-sm-6 content">
                        <div class="thumbnail">
                            <img alt="100%x200" data-src="holder.js/100%x200" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMTkyIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDE5MiAyMDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzEwMCV4MjAwCkNyZWF0ZWQgd2l0aCBIb2xkZXIuanMgMi42LjAuCkxlYXJuIG1vcmUgYXQgaHR0cDovL2hvbGRlcmpzLmNvbQooYykgMjAxMi0yMDE1IEl2YW4gTWFsb3BpbnNreSAtIGh0dHA6Ly9pbXNreS5jbwotLT48ZGVmcz48c3R5bGUgdHlwZT0idGV4dC9jc3MiPjwhW0NEQVRBWyNob2xkZXJfMTU2ZTgxMzExOTUgdGV4dCB7IGZpbGw6I0FBQUFBQTtmb250LXdlaWdodDpib2xkO2ZvbnQtZmFtaWx5OkFyaWFsLCBIZWx2ZXRpY2EsIE9wZW4gU2Fucywgc2Fucy1zZXJpZiwgbW9ub3NwYWNlO2ZvbnQtc2l6ZToxMHB0IH0gXV0+PC9zdHlsZT48L2RlZnM+PGcgaWQ9ImhvbGRlcl8xNTZlODEzMTE5NSI+PHJlY3Qgd2lkdGg9IjE5MiIgaGVpZ2h0PSIyMDAiIGZpbGw9IiNFRUVFRUUiLz48Zz48dGV4dCB4PSI3MS41IiB5PSIxMDQuNSI+MTkyeDIwMDwvdGV4dD48L2c+PC9nPjwvc3ZnPg==" data-holder-rendered="true" style="height: 200px; width: 100%; display: block;">
                            <div class="caption">
                                <h3>Thumbnail label</h3>
                                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                <p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-2 sidenav">
                    <div class="well">
                        <p>ADS</p>
                    </div>
                    <div class="well">
                        <p>ADS</p>
                    </div>
                </div>
            </div>
        </div>

        <footer class="container-fluid text-center">
            <p>Footer Text</p>
        </footer>
        <p>
            Az sym <?php echo $_smarty_tpl->tpl_vars['NAME']->value;?>

        </p>

        <?php if ($_GET['test']==6) {?>
            <?php echo $_smarty_tpl->getSubTemplate ('mainMenu.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php } elseif ($_GET['test']==5) {?>
            <p>
                evala bace, mashaala
            </p>
        <?php } else { ?>
            <p>
                nishtooo
            </p>
        <?php }?>


        <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['ss'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['name'] = 'ss';
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['TABLES']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['ss']['total']);
?>
            <?php echo $_smarty_tpl->tpl_vars['TABLES']->value[$_smarty_tpl->getVariable('smarty')->value['section']['ss']['index']]['Tables_in_store'];?>
 <br>
        <?php endfor; endif; ?>

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--<script src="../../node_modules/jquery/dist/jquery.min.js"></script> -->

        <!-- Latest compiled JavaScript -->
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- <script src="../../node_modules/bootstrap/dist/js/bootstrap.min.js"></script> -->

    </body>
</html>
<?php }} ?>
