# This is a Git Repo

### To install the necessary components  in the folder of the project - perform  from console:
- npm install

### Note: Needed node.js!
